
class AppColors {}