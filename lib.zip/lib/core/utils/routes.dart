import 'package:get/get.dart';
import 'package:intervu_ai/view/screens/splash/splash.dart';

class AppRoutes {
  static const String splash = '/';

  static final List<GetPage> pages = [
    GetPage(name: splash, page: () => const SplashScreen()),
  ];
}
